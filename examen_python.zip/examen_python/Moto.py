
import Vehicules

class Moto(Vehicules):

    type_vehicule = "Moto"

    def __init__(self, immat, annee, modele, marque, nb_roues, prix, couleur, vitesse, kilometrage):
        super().__init__(immat, annee,modele, marque, nb_roues, prix, couleur, vitesse, kilometrage)


    def decrire_vehicule(self):
        print 
        