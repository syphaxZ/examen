import datetime

import Vehicules



class App:
    application_name = "Gestion des véhicules"
    liste_vehicules =[]

    def __init__(self, liste_vehicules) -> None:
        self.liste_vehicules = liste_vehicules
        
    def get_vehicules(self):
        return self.liste_vehicules
    
    def set_vehicules(self, liste_veh):
        self.liste_vehicules = liste_veh

    # Ajout d'un véhicule à la liste des véhicules
    def ajouter_vehicule(self, vehicule):
        self.liste_vehicules.append(vehicule)

    def get_statistique(self):
        if len(self.liste_vehicules) == 0:
            print("Liste de véhicules vide !\n Aucune statistique à afficher")
        else:
            for vehicule in self.liste_vehicules:
                vehicule.decrire_vehicule()

if __name__ == "__main__":
    
    
    application = App([])

    vehicule_gen = Vehicules.Vehicules("aggj ghgj gj", 2000, "générique", "aucune", 0, 0.0, "défaut", 20, 0)
    application.ajouter_vehicule(vehicule_gen)
    
